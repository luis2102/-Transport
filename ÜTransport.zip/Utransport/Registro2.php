<!DOCTYPE >
<html>
<head>
  <meta charset="UTF-8">
  <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
<title>Registro</title>

<link rel="stylesheet" href="style4.css">

		<link rel="stylesheet" type="text/css" href="util.css">
	<link rel="stylesheet" type="text/css" href="main.css">

</head>

<body>
  <div id="nav">
    <ul>
      <li class="logo"><img src="logo2.png" alt="LOGO" height="40px" width="130px"></li>
      <li><a href="#" onclick="document.getElementById('modal-wrapper').style.display='block';">Login</a></li>
      <li class="opts"><a href="#">Acerca</a></li>
      <li class="opts"><a href="#">Rutas</a></li>
      <li class="opts"><a href="#">Inicio</a></li>
    </ul>
  </div>

<ul class="stepNav twoWide">
  <li class="selected">
  	<a href="" title="">INFORMACION</a>
  </li>
	<li>
		<a href="" title="">PAGO</a>
	</li>
</ul>

	<div class="container-contact100">
		<div class="wrap-contact100">
			<form class="contact100-form validate-form">
        <h1 align="center">Hola, Silvana Medina Campos</h1>

				<div class="wrap-input100 validate-input bg1" data-validate="Nombre: ">
					<span class="label-input100">NOMBRE</span>
					<input class="input100" type="text" name="name" readonly="readonly" value="Silvana Medina Campos">
				</div>

				<div class="wrap-input100 validate-input bg1 rs1-wrap-input100" data-validate = "Enter Your Email (e@a.x)">
					<span class="label-input100">Email</span>
					<input class="input100" type="text" name="email" readonly="readonly" value="silvana@gmail.com">
				</div>

				<div class="wrap-input100 bg1 rs1-wrap-input100">
					<span class="label-input100">CELULAR</span>
					<input class="input100" type="text" name="phone" readonly="readonly" value="2224567890">
				</div>

				<div class="wrap-input100 input100-select bg1">
					<span class="label-input100">Cuentas con alguna limitacion o deficiencia motriz *</span>
					<div>
						<select class="js-select2" name="service">
							<option>No</option>
							<option>Si</option>
						</select>
						<div class="dropDownSelect2"></div>
					</div>
				</div>
				<div class="container-contact100-form-btn">
					<button class="contact100-form-btn" onclick="FormaPago.php" style="background-color: #009fd8;">
						<span>
						<a href="FormaPago.php">	CONTINUAR</a>
              <i class="fa fa-long-arrow-right"  aria-hidden="true"></i>

						</span>
					</button>
				</div>
			</form>
		</div>
	</div>

</body>
</html>
