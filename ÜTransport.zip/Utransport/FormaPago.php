<?php
$var=0;
session_start();

if (!isset($_SESSION['count'])) {
	$var=$_SESSION['count'] = 0;
} else {
	$_SESSION['count']++;
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Invitado</title>

<link rel="stylesheet" href="style4.css">
<link rel="stylesheet" href="style5.css">
	<link rel="stylesheet" href="styles.css">


		<link rel="stylesheet" type="text/css" href="util.css">
	<link rel="stylesheet" type="text/css" href="main.css">

		<script src="at.js"></script>

</head>

<body>

	<div id="nav">
		<ul>
			<li class="logo"><img src="logo2.png" alt="LOGO" height="40px" width="130px"></li>
      <li><a href="#" onclick="document.getElementById('modal-wrapper').style.display='block';">Login</a></li>
      <li class="opts"><a href="#">Acerca</a></li>
      <li class="opts"><a href="ruta.php">Rutas</a></li>
      <li class="opts"><a href="home.php">Inicio</a></li>
		</ul>
	</div>
<ul class="stepNav twoWide">
  <li >
  	<a href="" title="">INFORMACION</a>
  </li>
	<li class="selected">
		<a href="" title="">PAGO</a>
	</li>
</ul>

<!-- Tab links -->
<div class="tab">
  <button class="tablinks" onclick="openCity(event, 'London')">Tarjeta</button>
  <button class="tablinks" onclick="openCity(event, 'Paris')">Efectivo</button>
</div>

<!-- Tab content -->
<div id="London" class="tabcontent">
  <h3>Tarjeta</h3>
  <p>London is the capital city of England.</p>
</div>

<div id="Paris" class="tabcontent">
  <h3>Efectivo</h3>
  <p>Paris is the capital of France.</p>

<div class="box">
	<a class="button" href="#popup1" onload="loadGraph()">Generar Codigo</a>
</div>

<div id="popup1" class="overlay">
	<div class="popup">
		<h2>Escanea tu Codigo QR</h2>
		<a class="close" href="#">&times;</a>
		<div class="content">
				<form action='https://chart.googleapis.com/chart' method='POST' id='post_form'
          onsubmit="this.action = 'https://chart.googleapis.com/chart?chid=' + (new Date()).getMilliseconds(); return true;">  <input type='hidden' name='cht' value='qr' />
      <input type='hidden' name='cht' value='qr' />
      <input type='hidden' name='chs' value='300x300' />
      <input type='hidden' name='chl' value='El costo total es: $7.50 ' />
      <input type='submit' />
    </form>
		</div>
	</div>
</div>
</div>
</div>
				<div class="container-contact100-form-btn">
						<span>
							<a href="#">Finalizar</a>
							<i class="fa fa-long-arrow-right m-l-7" aria-hidden="true"></i>
						</span>
					</button>
				</div>
			</form>
		</div>
	</div>
</body>
</html>
