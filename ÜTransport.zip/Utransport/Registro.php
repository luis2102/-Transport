<?php 
	if (isset($_POST['enviar'])) {
		header("Location: Registro2.php");
		exit();
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
	<title>Document</title>
</head>
<body>
  <div id="nav">
    <ul>
      <li class="logo"><img src="logo2.png" alt="LOGO" height="40px" width="130px"></li>
      <li class="opts"><a href="home.php">Inicio</a></li>
    </ul>
  </div>  
	<div class="container">
    <h1 style="text-align: center; font-size: 50px;">¡&Uacute;nete!</h1>
    <p style="font-size: 25px; padding-top: 20px;">Obten beneficios al mejorar la movilidad de la ciudad, como:</p>
    <div class="ben">
      <p style="padding-top: 15px; padding-left: 15px;"><span id="check">&#10004;</span>Descuentos al realizar viajes ecológicos.<p>
      <p style="padding-top: 15px; padding-left: 15px;"><span id="check">&#10004;</span>Asistente de movilidad.<p>
      <p style="padding-top: 15px; padding-left: 15px;"><span id="check">&#10004;</span>Puntos de viaje.<p>
      <p style="padding-top: 15px; padding-left: 15px;"><span id="check">&#10004;</span>Agilización de compra.<p>
      <p style="padding-top: 15px; padding-left: 15px;"><span id="check">&#10004;</span>Información de la ciudad.<p>
    </div>

    <!-- <form action="respuesta.php" method="post" name="respuesta1_1" value=1> -->
    <form method="post" name="respuesta1_1" value=1>
      <div id="P_form">Nombre</div>
      <input type="text" name="nombre1" placeholder="Tu nombre..." required>
      <div id="P_form">Apellido
      <input type="text" name="nombre1" placeholder="Tu apellido..." required>
    </div>
      <div id="P_form">N&uacute;mero telef&oacute;nico</div>
      <input type="text" name="nombre1" placeholder="Tu teléfono..." required>
      <div id="P_form">Correo</div>
      <input type="text" name="nombre1" placeholder="Tu correo..." required>
      <div id="P_form">Contrase&ntilde;a</div>
      <input type="password" name="pass1" placeholder="Tu contrase&ntilde;a..." required>
      <div id="btn">
        <input type="submit" name="enviar" value="Unirse"><br>
      </div>
    </form>
    <br>
  </div>
</body>
</html>