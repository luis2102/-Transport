<?php 
$var=0;
session_start();

if (!isset($_SESSION['count'])) {
	$var=$_SESSION['count'] = 0;
} else {
	$_SESSION['count']++;
}
?>
<?php 
if (isset($_POST['BuscaViaje'])) {
	$_SESSION['origen'] = $_POST['origen'];
	$_SESSION['destino'] = $_POST['destino'];
	$_SESSION['fecha'] = $_POST['hora'];
	$_SESSION['hora'] = $_POST['fecha'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<link href="https://fonts.googleapis.com/css?family=Muli" rel="stylesheet"> 
	<link rel="stylesheet" href="styles.css">
	<title>Übergibt Transport</title>
	<!-- <script src="https://code.jquery.com/jquery-1.10.2.js"></script> -->
	<script>
		var intrvl = setInterval(function(){plusSlides(1)},5000);

		var today = new Date();

		function setDate(){
			var date = today.toISOString().slice(0,10);
			var f = document.getElementById('fecha');
			f.value = date;
		}
		window.onload=function(){
			setDate();
		}
		function setTime(){
			var time = today.getHours() + ":" + today.getMinutes();
			var f = document.getElementById('hora');
			f.value = time;
		}
	</script>
</head>
<body>
	<div id="nav">
		<ul>
			<li class="logo"><img src="logo2.png" alt="LOGO" height="40px" width="130px"></li>
			<li><a href="#" onclick="document.getElementById('modal-wrapper').style.display='block';">Login</a></li>
			<li class="opts"><a href="#">Acerca</a></li>
			<li class="opts"><a href="ruta.php">Rutas</a></li>
			<li class="opts"><a href="#">Inicio</a></li>
		</ul>
	</div>
	<div id="modal-wrapper" class="modal">

		<form class="modal-content animate" action="/action_page.php">
		<span onclick="document.getElementById('modal-wrapper').style.display='none'" class="close" title="Close PopUp" style="float:right;">&times;</span>

		<div id="forma">
		<img src="UserAdmin.png" alt="IconoPersona" style="max-width: 50%; display: block; margin:auto; padding-bottom: 25px;" >
		<!-- <form action="respuesta.php" method="post" name="respuesta1_1" value=1> -->
		<form method="post" name="respuesta1_1" value=1>
			<div id="P_form">Usuario</div>
			<input type="text" name="nombre1" placeholder="Tu usuario..." required>
			<div id="P_form">Contrase&ntilde;a</div>
			<input type="password" name="pass1" placeholder="Tu contrase&ntilde;a..." required>
			<div id="btn">
				<input type="submit" name="enviar" value="Ingresar"><br>
			</div><br>
			<div id="noAcc">
				<a href="Registro.php">¿No tienes una cuenta? Reg&iacute;strate.</a>
			</div>
		</form>
		<br>
	</div>

		</form>

	</div>
	<div class="slideshow-container">
		<!-- Slides principales -->
		<div class="mySlides fade">
			<img src="cate.jpg" alt="Catedral de Puebla" width="100%" height="500vh" style="width:100%">
		</div>
		<div class="mySlides fade">
			<img src="midb.jpg" alt="Museo Internacional del Barroco" width="100%" height="500vh" style="width:100%">
		</div>
		<div class="mySlides fade">
			<img src="estrellaP.png" alt="Estrella de Puebla" width="100%" height="500vh" style="width:100%">
		</div>

		<!-- forma de búsqueda dentro de la imagen -->
		<div class="searchForm">
			<form action="ruta.php" autocomplete="off" method="post">
				<div style="text-align: center; padding-top: 30px; font-size: 30px;" >¡Elige tu destino!</div>
				<br><br>
				<span>Origen</span><br>
				<select>
  					<option value="">-- Seleccione una opción --</option>
  					<option value="Catedral de Puebla">Catedral de Puebla</option>
  					<option value="El Parián">El Parián</option>
  					<option value="Estrella de Puebla">Estrella de Puebla</option>
  					<option value="Museo Internacional del Barroco">Museo Internacional del Barroco</option>
				</select>
				<br><br>
				<select>
  					<option value="">-- Seleccione una opción --</option>
  					<option value="Catedral de Puebla">Catedral de Puebla</option>
  					<option value="El Parián">El Parián</option>
  					<option value="Estrella de Puebla">Estrella de Puebla</option>
  					<option value="Museo Internacional del Barroco">Museo Internacional del Barroco</option>
				</select>
				<br><br>
				<div style="display: flex;">
					<div style="max-width: 30%; margin-right: 15%;">
						<span>Hora</span><br>
						<span><input type="time" name="hora" id="hora"></span>
					</div>
					<div style="float:right;">
						<span>Fecha</span><br>
						<span ><input type="date" name="fecha" id="fecha"></span>
					</div>
				</div>
				<div style="margin-top: 15px;">
					<input type="submit" name="BuscaViaje" value="Buscar">
				</div>
			</form>
		</div>
		<!-- flechitas del slide -->
		<a class="prev" onclick="plusSlides(-1)">&#10094;</a>
		<a class="next" onclick="plusSlides(1)">&#10095;</a>

	</div>
	<br>

	<div style="text-align:center">
		<span class="dot" onclick="currentSlide(1)"></span> 
		<span class="dot" onclick="currentSlide(2)"></span> 
		<span class="dot" onclick="currentSlide(3)"></span> 
	</div>
	
	<script>
		var slideIndex = 1;
		showSlides(slideIndex);

		function plusSlides(n) {
			showSlides(slideIndex += n);
		}

		function currentSlide(n) {
			showSlides(slideIndex = n);
		}

		function showSlides(n) {
			var i;
			var slides = document.getElementsByClassName("mySlides");
			var dots = document.getElementsByClassName("dot");
			if (n > slides.length) {slideIndex = 1}    
				if (n < 1) {slideIndex = slides.length}
					for (i = 0; i < slides.length; i++) {
						slides[i].style.display = "none";  
					}
					for (i = 0; i < dots.length; i++) {
						dots[i].className = dots[i].className.replace(" active", "");
					}
					slides[slideIndex-1].style.display = "block";  
					dots[slideIndex-1].className += " active";
				}
		
	</script>
			<div>
				<ul class="row">
					<li class="column"><img src="parian.jpg" alt="El Parián" ></li>
					<li class="column"><img src="cH.jpg" alt="Centro Histórico"></li>
					<li class="column"><img src="parian.jpg" alt="El Parián"></li>
				</ul>
			</div>

	<!-- <div class="row">
		<div class="column">
			<img src="midb.jpg" alt="Museo Internacional del Barroco">
		</div>
		<div class="column">
			<img src="cH.jpg" alt="Centro Histórico">
		</div>
		<div class="column">
			<img src="parian.jpg" alt="El Parián">
		</div>
	</div>
	<br><br>
	<div class="row">
		<div class="column">
			<img src="cd1.jpg" alt="Catedral de Puebla">
		</div>
		<div class="column">
			<img src="cs2.jpg" alt="Centro Histórico">
		</div>
		<div class="column">
			<img src="cd3.jpg" alt="El Parián">
		</div> -->
	</div>
</body>
</html>