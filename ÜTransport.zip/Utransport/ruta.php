<?php
session_start();
?>
<?php

$org=$_POST['origen'];
$dest= $_POST['destino'];
$hor=$_POST['hora'];
$fech=$_POST['fecha'];

?>

<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no">
    <meta charset="utf-8">
    <title>Travel Modes in Directions</title>
    <link rel="stylesheet" href="styles.css">
    <style>

      #map {
        height: 425px;
      }

      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
      #floating-panel {
        top: 10px;
        left: 50%;
        z-index: 5;
        background-color: #fff;
        padding: 5px;
        border: 1px solid #999;
        text-align: center;
        font-family: 'Muli', sans-serif;
        color: #333;
        line-height: 30px;
        padding-left: 40px;
      }
      .button {
        background-color: #4CAF50;
        border: none;
        color: white;
        padding: 15px 25px;
        text-align: center;
        font-size: 16px;
        cursor: pointer;
      }

      .button:hover {
        background-color: green;
      }

    </style>
  </head>
  <body>
			<form action="ruta.php" autocomplete="off" method="post">
    <div id="nav">
      <ul>
        <li class="logo"><img src="logo2.png" alt="LOGO" height="40px" width="130px"></li>
        <li class="opts" style="hidden background-color: #009fb8"><a id="demo" href="Guess(Invitado)Informacion.html"></a></li>
        <li class="opts"><a href="home.php">Inicio</a></li>

      </ul>
    </div>
</form>
        <div id="map"></div>
    <div id="floating-panel">
      <div id="right-panel">

      <b>1. Origen: </b>
      <select id="start">
        <option value="" selected>-- Selecciona una opción --</option>
        <option value="Dentro de Parque Tecnologico, Atlixcáyotl 2301, Reserva Territorial Atlixcáyotl, 72434 Puebla, Pue." >Ubicación actual</option>
        <option value="Estrella de Puebla, Osa Mayor, Reserva Territorial Atlixcáyotl, Centros Comerciales Desarrollo Atlixcayotl, Heroica Puebla de Zaragoza, Pue., México">Estrella de Puebla</option>
        <option value="Catedral de Puebla, Calle 16 de Septiembre, Centro Histórico, Heroica Puebla de Zaragoza, Pue., México">Catedral de Puebla</option>
        <option value="Calle 6 Nte 205, Centro, 72000 Puebla, Pue.">El Parián</option>
        <option value="Atlixcáyotl 2501, Reserva Territorial Atlixcáyotl, 72830 Puebla, Pue.">Museo del Barroco</option>
      </select>
      <b>2. Destino: </b>
      <select id="end">
        <option value="" selected>-- Selecciona una opción --</option>
        <option value="Estrella de Puebla, Osa Mayor, Reserva Territorial Atlixcáyotl, Centros Comerciales Desarrollo Atlixcayotl, Heroica Puebla de Zaragoza, Pue., México">Estrella de Puebla</option>
        <option value="Catedral de Puebla, Calle 16 de Septiembre, Centro Histórico, Heroica Puebla de Zaragoza, Pue., México">Catedral de Puebla</option>
        <option value="Calle 6 Nte 205, Centro, 72000 Puebla, Pue.">El Parián</option>
        <option value="Atlixcáyotl 2501, Reserva Territorial Atlixcáyotl, 72830 Puebla, Pue.">Museo del Barroco</option>
      </select>
    <b>3. Tipo de Traslado: </b>
    <select id="mode">
      <option value="BICYCLING">Ecológico</option>
      <option value="TRANSIT">Económico</option>
      <option value="DRIVING">Rápido</option>
    </select>
    </div>

    <script>
      function initMap() {
        //var directionsService = new google.maps.DirectionsService;destino
        //var directionsDisplay = new google.maps.DirectionsRenderer;destimo
        var directionsDisplay = new   google.maps.DirectionsRenderer({
        draggable: false,
        map: map,
        panel: document.getElementById('right-panel')
      });
      //MOSTRAR PASOS
      directionsDisplay.addListener('directions_changed', function() {

        computeTotalDistance(directionsDisplay.getDirections());
      });

        var directionsService = new google.maps.DirectionsService;
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 11,
          center: {lat: 19.019634, lng: -98.244886} //PUEBLA
          //center: {lat: 41.85, lng: -87.65} //CHICAGO
          //center: {lat: 37.77, lng: -122.447} //SAN FRANCISCO
        });
        directionsDisplay.setMap(map);


        var onChangeHandler = function() { //LINEA DE ORIGEN DESTINO
        calculateAndDisplayRoute(directionsService, directionsDisplay);
      };
      // document.getElementById('start').addEventListener('change', onChangeHandler); //ORIGEN Destino
      document.getElementById('end').addEventListener('change', onChangeHandler); //ORIGEN DESTINO
        document.getElementById('mode').addEventListener('change', function() {
          calculateAndDisplayRoute(directionsService, directionsDisplay);
          document.getElementById("demo").innerHTML = "Comprar Ruta";
        });

      }

      //FUNCION PARA MOSTRAR RUTA CON TEXTO

      function calculateAndDisplayRoute(directionsService, directionsDisplay) {
        document.getElementById("demo").innerHTML = "Comprar Ruta";
        var selectedMode = document.getElementById('mode').value;
        directionsService.route({
          //origin: {lat: 37.77, lng: -122.447},  // Haight.
          //destination: {lat: 37.768, lng: -122.511},  // Ocean Beach.
          origin: document.getElementById('start').value, //DESTINO
          destination: document.getElementById('end').value, //DESTINO
          travelMode: google.maps.TravelMode[selectedMode]
        }, function(response, status) {
          if (status == 'OK') {
            directionsDisplay.setDirections(response);
            document.getElementById("demo").innerHTML = "Comprar Ruta";
          } else {
            window.alert('Directions request failed due to ' + status);
          }
        });
      }
      function computeTotalDistance(result) {
        document.getElementById("demo").innerHTML = "Comprar Ruta";
        var total = 0;
        var myroute = result.routes[0];
        for (var i = 0; i < myroute.legs.length; i++) {
          total += myroute.legs[i].distance.value;
        }
        total = total / 1000;
        document.getElementById('total').innerHTML = total + ' km';
        document.getElementById("demo").innerHTML = "Comprar Ruta";
      }
    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCKnq2zz040vIeLxX2slXEWD00W0hvqOOo&callback=initMap">
    </script>
  </body>
</html>
